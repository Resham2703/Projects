package com.jspiders.cardekho_case_study.main;

import java.util.Scanner;

import com.jspiders.cardekho_case_study.operation.caroperation;

public class cardekhomenu {

	public static void main(String[] args) {
		caroperation caroperation = new caroperation();
		System.out.println("SELECT YOUR CHOICE ");

		mainMenu();

		System.out.println("Thank You  For Your Valuable Time ! ");

	}

	static Scanner sc = new Scanner(System.in);

	public static void mainMenu() {
		System.out.println("========MENU=======\n" + "1.Add/Remove Car\n" + "2.Update Car Details\n"
				+ "3.Search Car Details\n" + "4.Display All Car Details\n" + "5.Exit\n");
		int k = sc.nextInt();
		switch (k) {
		case 1: {
			addRemove();
			mainMenu();
			break;
		}
		case 2: {

			caroperation.updateCarDetails();
			mainMenu();
			break;
		}
		case 3: {
			searchMenu();
			mainMenu();
			break;
		}
		case 4: {
			caroperation.displayADetails();
			mainMenu();
		}
		case 5: {
			return;
		}
		default: {
			System.out.println("Invalid Choice! ");
			mainMenu();
		}
		}

	}

	public static void addRemove() {
		System.out
				.println("========MENU=======\n" + "1.Add Car Details\n" + "2.Remove Car Details\n" + "3.main Menu\n");
		int k = sc.nextInt();
		switch (caroperation.get_Choice(k)) {
		case 1: {

			caroperation.Add_Car();
			break;
		}
		case 2: {
			caroperation.Remove_Car();
			break;
		}
		case 3: {
			mainMenu();
			break;
		}
		default: {
			addRemove();
		}
		}
	}

//--------------SearchCarMenu------------
	public static void searchMenu() {
		caroperation.searchCar();

	}

//--------------Update Menu-------------

	public static void updateMenu() {

		caroperation.updateCarDetails();
		mainMenu();
	}

	// ---------get the input---------

}