package com.jspiders.cardekho_case_study.operation;

import java.util.*;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.jspiders.cardekho_case_study.entity.car;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.io.FileInputStream;
import java.util.Scanner;
import java.util.Properties;

public class caroperation extends car {

	private static Connection connection;
	private static PreparedStatement preparedStatement;
	private static int result;
	private static String query;
	private static ResultSet resultSet;
	private static Properties properties = new Properties();
	private static FileInputStream file;
	private static String filepath = "D:\\WEJA2\\Jdbc\\Resources\\db_info.properties";

	static Scanner sc = new Scanner(System.in);

	// static ArrayList<car> obj = new ArrayList<car>();

	// -------New Add Car Details--------
	public static void Add_Car() {
		try {
			openConnection();

			query = "insert into emp01 values(?,?,?,?,?)";
			preparedStatement = connection.prepareStatement(query);
			System.out.println("how many car do you want to add: ");
			int noOfCars = sc.nextInt();
			int no = 1;
			while (noOfCars >= no) {
				car car = new car();
				System.out.println("enter car id");
				car.set_Car_id(sc.nextInt());

				System.out.println("enter car name");
				car.set_Car_name(sc.next());

				System.out.println("enter car brand");
				car.set_Brand(sc.next());

				System.out.println("enter car fual type");
				car.set_fuel_type(sc.next());

				System.out.println("enter car price");
				car.set_price(sc.nextDouble());

				preparedStatement.setInt(1, car.get_Car_id());
				preparedStatement.setString(2, car.getCar_name());
				preparedStatement.setString(3, car.get_Brand());
				preparedStatement.setString(4, car.get_fuel_type());
				preparedStatement.setDouble(5, car.get_price());

				result = preparedStatement.executeUpdate();

				System.out.println(no + " car(s) added");
				no++;

//				
//				}
//			
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeConnection();
		}

	}

//	//------------Remove Car ----------
	public static void Remove_Car() {
		try {
			displayADetails();
			openConnection();
			query = "delete from emp01 " + "where car_id = ? ";

			preparedStatement = connection.prepareStatement(query);

			System.out.println("Which Car You Want To Delete");
			int car_id = sc.nextInt();

			preparedStatement.setInt(1, car_id);
			result = preparedStatement.executeUpdate();
			System.out.println(result + " car deleted");

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeConnection();
		}

//		displayADetails();
//		System.out.println("Enter Your Car Number Do You Want To Delete : ");
//		int a=sc.nextInt();
//		obj.remove(a-1);
//		System.out.println("\n------Successfully Remove the Car-------\n");
	}

//	
//	
//	//-------------Search Car-----------
	public static void searchCar() {
		try {
//			displayADetails();
			openConnection();

			System.out.println("On which you want to search \n 1. by name \n 2.by brand \n 3.fualtype");
			int choice = sc.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Enter Car Name");
				String name = sc.next();
				query = " select * from emp01 " + "where car_name = ?  ";

				preparedStatement = connection.prepareStatement(query);

				preparedStatement.setString(1, name);
				resultSet = preparedStatement.executeQuery();

				while (resultSet.next()) {
					System.out.println(
							resultSet.getString(1) + " || " + resultSet.getString(2) + " || " + resultSet.getString(3)
									+ " || " + resultSet.getString(4) + " || " + resultSet.getString(5));
				}

				break;
			case 2:
				openConnection();
				System.out.println("Enter Car Brand");
				String brand = sc.next();

				query = " select * from emp01 " + " where car_brand = ? ";

				preparedStatement = connection.prepareStatement(query);

				preparedStatement.setString(1, brand);
				resultSet = preparedStatement.executeQuery();

				while (resultSet.next()) {
					System.out.println(
							resultSet.getString(1) + " || " + resultSet.getString(2) + " || " + resultSet.getString(3)
									+ " || " + resultSet.getString(4) + " || " + resultSet.getString(5));
				}
				break;

			case 3:
				openConnection();
				System.out.println("Enter Car Fual_Type");
				String fual = sc.next();

				query = " select * from emp01 " + " where car_fualtype = ? ";

				preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(1, fual);
				resultSet = preparedStatement.executeQuery();

				while (resultSet.next()) {
					System.out.println(
							resultSet.getString(1) + " || " + resultSet.getString(2) + " || " + resultSet.getString(3)
									+ " || " + resultSet.getString(4) + " || " + resultSet.getString(5));
				}

			default:
				break;
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeConnection();
		}
	}

////------------------Display All Details ------------
	public static void displayADetails() {
		try {

			openConnection();
			query = "select * from emp01 ";

			preparedStatement = connection.prepareStatement(query);

			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {

				System.out.println(resultSet.getString(1) + " | " + resultSet.getString(2) + " | "
						+ resultSet.getString(3) + " | " + resultSet.getString(4) + " | " + resultSet.getString(5));
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeConnection();
		}
	}

//	//------------------------Update Car Details ------------------
//	
	public static int get_Choice(int a) {
//		

//		}
		return a;
	}

	public static void updateCarDetails() {
		try {
			displayADetails();
			openConnection();
			System.out.println("What You Want to update ?  \n 1.Name \n 2. Brand \n 3.price");
			int choice = sc.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Enter Car Id ");
				int id = sc.nextInt();

				System.out.println("Enter New Car Name");
				String name = sc.next();
				query = " update emp01 " + " set car_name = ? " + " where car_id = ? ";

				preparedStatement = connection.prepareStatement(query);

				preparedStatement.setString(1, name);
				preparedStatement.setInt(2, id);

				result = preparedStatement.executeUpdate();

				System.out.println("Car Name Updated Successfully");

				break;

			case 2:

				System.out.println("Enter Car Id ");
				int id1 = sc.nextInt();

				System.out.println("Enter Car Brand");
				String brand = sc.next();

				query = " update emp01 " + " set car_brand = ? " + " where car_id = ? ";

				preparedStatement = connection.prepareStatement(query);
				preparedStatement.setInt(2, id1);
				preparedStatement.setString(1, brand);

				result = preparedStatement.executeUpdate();
				System.out.println("Car Brand Updated Successfully");

				break;
			case 3:
				System.out.println("Enter Car Id ");
				int id3 = sc.nextInt();

				System.out.println("Enter Car Price");
				double price = sc.nextDouble();

				query = " update emp01 " + " set car_price = ? " + " where car_id = ? ";

				preparedStatement = connection.prepareStatement(query);
				preparedStatement.setInt(2, id3);
				preparedStatement.setDouble(1, price);

				result = preparedStatement.executeUpdate();
				System.out.println("Car Price Updated Successfully");

			default:
				break;
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeConnection();
		}

	}

	private static void openConnection() {

		try {

			file = new FileInputStream(filepath);
			properties.load(file);

			// Load Driver Class
			Class.forName(properties.getProperty("driverpath"));

			// Open Open Statement
			connection = DriverManager.getConnection(properties.getProperty("dburl"), properties);

			// Create statement

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private static void closeConnection() {
		try {
			if (connection != null) {
				connection.close();
			}
			if (preparedStatement != null) {
				preparedStatement.close();
			}
			if (resultSet != null) {
				resultSet.close();
			}
			if (result != 0) {
				result = 0;
			}
			if (file != null) {
				file.close();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
