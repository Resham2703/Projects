package com.jspiders.cardekho_case_study_mvc.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jspiders.cardekho_case_study_mvc.Pojo.carPojo;
import com.jspiders.cardekho_case_study_mvc.Repository.carRepository;

@Service
public class carService {

	@Autowired
	private carRepository repository;

	public carPojo addCar(String carName, String carBrand, String carFual, double carPrice) {
		carPojo pojo = repository.addCar(carName, carBrand, carFual, carPrice);
		return pojo;
	}

	public List<carPojo> findAllCar() {
		List<carPojo> carspojo = repository.findAllCar();
		return carspojo;
	}

	public carPojo searchCar(int id) {
		carPojo pojo = repository.searchCar(id);
		return pojo;
	}

	public carPojo updateCar(int id, String carName, String carBrand, String carFual, double carPrice) {
		carPojo pojo = repository.updateCar(id, carName, carBrand, carFual, carPrice);
		return pojo;
	}

	public carPojo removeCar(int id) {
		carPojo pojo = repository.removeCar(id);
		return pojo;
	}

}
