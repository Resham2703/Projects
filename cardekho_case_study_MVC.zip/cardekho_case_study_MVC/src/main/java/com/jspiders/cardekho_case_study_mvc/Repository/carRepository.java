package com.jspiders.cardekho_case_study_mvc.Repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.jspiders.cardekho_case_study_mvc.Pojo.carPojo;

@Repository
public class carRepository {


	private static EntityManagerFactory entityManagerFactory;
	private static EntityManager entityManager;
	private static EntityTransaction entityTransaction;
	private static Query query;

	private static void openConnection() {
		entityManagerFactory = Persistence.createEntityManagerFactory("mvc1");
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction = entityManager.getTransaction();
	}

	private static void closeConnection() {
		if (entityManagerFactory != null) {
			entityManagerFactory.close();
		}
		if (entityManager != null) {
			entityManager.close();
		}
		if (entityTransaction != null) {
			if (entityTransaction.isActive()) {
				entityTransaction.rollback();
			}
		}
	}

	
	public carPojo addCar(String carName, String carBrand, String carFual, double carPrice) {
		openConnection();
		entityTransaction.begin();
		
		carPojo pojo = new carPojo();
		pojo.setCarName(carName);
		pojo.setCarBrand(carBrand);
		pojo.setCarFual(carFual);
		pojo.setCarPrice(carPrice);
		
		entityManager.persist(pojo);
		
		entityTransaction.commit();
		closeConnection();
		return pojo;
	}

	public List<carPojo> findAllCar() {
		openConnection();
		entityTransaction.begin();
		String jpql = "from carPojo";
		query =entityManager.createQuery(jpql);
		List<carPojo>cars = query.getResultList();
		entityTransaction.commit();
		closeConnection();
		return cars;
	}

	public carPojo searchCar(int id) {
		openConnection();
		entityTransaction.begin();
		
		carPojo pojo = entityManager.find(carPojo.class,id);
		
		entityTransaction.commit();
		closeConnection();
		return pojo;
	}

	public carPojo updateCar(int id, String carName, String carBrand, String carFual, double carPrice) {
		openConnection();
		entityTransaction.begin();
		
		carPojo pojo = entityManager.find(carPojo.class, id);
		pojo.setCarName(carName);
		pojo.setCarBrand(carBrand);
		pojo.setCarFual(carFual);
		pojo.setCarPrice(carPrice);
		
		entityManager.persist(pojo);
		
		entityTransaction.commit();
		closeConnection();
		return pojo;
	}

	public carPojo removeCar(int id) {
		openConnection();
		entityTransaction.begin();
		
		carPojo pojo = entityManager.find(carPojo.class,id);
		if(pojo != null) {
			entityManager.remove(pojo);
		}
		
		entityTransaction.commit();
		closeConnection();
		return pojo;
	}

	

}
