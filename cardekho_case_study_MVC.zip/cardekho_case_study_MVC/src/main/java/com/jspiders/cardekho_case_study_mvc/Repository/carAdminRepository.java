package com.jspiders.cardekho_case_study_mvc.Repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;

import com.jspiders.cardekho_case_study_mvc.Pojo.carAdminPojo;


@Repository

public class carAdminRepository {
	private static EntityManagerFactory factory;
	private static EntityManager manager;
	private static EntityTransaction transaction;
	private static Query query;

	private static void OpenConnection() {
		factory = Persistence.createEntityManagerFactory("mvc1");
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
	}

	private static void CloseConnection() {
		if (factory != null) {
			factory.close();
		}
		if (manager != null) {
			manager.close();
		}
		if (transaction != null) {
			if (transaction.isActive())
				
			{
				transaction.rollback();
			}
		}
	}

	public carAdminPojo getAdmin() {

		OpenConnection();
		transaction.begin();

		String jpql = "from carAdminPojo";
		query = manager.createQuery(jpql);

		@SuppressWarnings("unchecked")
		List<carAdminPojo> admins = query.getResultList();

		if (admins.isEmpty() == false) {
			for (carAdminPojo pojo : admins) {
				transaction.commit();
				CloseConnection();
				return pojo;
			}
		}

		transaction.commit();
		CloseConnection();
		return null;

	}

	public carAdminPojo createAccount(String username, String password) {

		OpenConnection();
		transaction.begin();
		carAdminPojo pojo = new carAdminPojo();
		pojo.setUsername(username);
		pojo.setPassword(password);

		manager.persist(pojo);
		transaction.commit();
		CloseConnection();

		return pojo;
	}

	public  carAdminPojo login(String username , String password) {
		
		OpenConnection();
		transaction.begin();
		
		String jpql = "from carAdminPojo where username = '"+username+"' and password = '"+password+"'";
		
		
		query = manager.createQuery(jpql);
		
		List<carAdminPojo>admins = query.getResultList();
		if(admins.isEmpty() == false) {
			
			for(carAdminPojo pojo : admins) {
			transaction.commit();
			CloseConnection();
			System.out.println(pojo);
			return pojo;
			}
		}
		
		transaction.commit();
		CloseConnection();
		return null;
		
	}

}
