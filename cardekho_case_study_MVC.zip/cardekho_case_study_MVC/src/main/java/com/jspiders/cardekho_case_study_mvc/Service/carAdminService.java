package com.jspiders.cardekho_case_study_mvc.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.jspiders.cardekho_case_study_mvc.Pojo.carAdminPojo;
import com.jspiders.cardekho_case_study_mvc.Repository.carAdminRepository;

@Service
public class carAdminService {
	
	@Autowired 
	private carAdminRepository repository;

	public carAdminPojo getAdmin() {
		carAdminPojo pojo =  repository.getAdmin();
		return pojo;
	}
	
	public carAdminPojo createAccount(String username , String password) {
		
		carAdminPojo pojo = repository.createAccount(username,password);
		return pojo;
	}
	
	public carAdminPojo login(String username , String password) {
		carAdminPojo pojo = repository.login(username,password);
		return pojo;
	}


}
