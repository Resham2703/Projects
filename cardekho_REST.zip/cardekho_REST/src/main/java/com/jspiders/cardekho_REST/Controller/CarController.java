package com.jspiders.cardekho_REST.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jspiders.cardekho_REST.Pojo.CarPojo;
import com.jspiders.cardekho_REST.Response.CarResponse;
import com.jspiders.cardekho_REST.Service.CarService;


@RestController
public class CarController {

	@Autowired
	private CarService service;

	@PostMapping(path = "/add", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CarResponse> addCar(@RequestBody CarPojo pojo) {

		CarPojo car = service.addCar(pojo);

		// Success

		if (car != null) {
			return new ResponseEntity<CarResponse>(new CarResponse("Car Is Added Your Database", car, null),
					HttpStatus.ACCEPTED);
		}
		// Failure
		return new ResponseEntity<CarResponse>(new CarResponse("Data Not Added Your Database.. !", null, null),
				HttpStatus.NOT_ACCEPTABLE);

	}

	@GetMapping(path = "/search", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CarResponse> searchCar(@RequestParam int id) {

		CarPojo car = service.searchCar(id);

		if (car != null) {
			return new ResponseEntity<CarResponse>(new CarResponse("Data Found In Your Databbases..!", car, null),
					HttpStatus.FOUND);
		}
		return new ResponseEntity<CarResponse>(new CarResponse("Data Not Found In Your Database...!", null, null),
				HttpStatus.NOT_FOUND);
	}

	@GetMapping(path = "/searchAllCars", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CarResponse> searchAllCars() {

		List<CarPojo> cars = service.searchAllCars();
		// Success
		if (cars.isEmpty() == false) {
			return new ResponseEntity<CarResponse>(new CarResponse("Data  found. ", null, cars), HttpStatus.FOUND);

		}
		// Failure
		return new ResponseEntity<CarResponse>(new CarResponse("Data not found. ", null, null), HttpStatus.NOT_FOUND);
	}

	@DeleteMapping(path = "/remove/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CarResponse> removeCar(@PathVariable int id) {
		CarPojo car = service.removeCar(id); 
		if (car != null) {
			return new ResponseEntity<CarResponse>(new CarResponse("Car Is Removed", car, null), HttpStatus.OK);
		}
		return new ResponseEntity<CarResponse>(new CarResponse("Data Not Removed", null, null), HttpStatus.BAD_REQUEST);

	}
	@PutMapping(path = "/update", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CarResponse> updateCar(@RequestBody CarPojo pojo) {

		CarPojo car = service.updateCar(pojo);
		// Success
		if (car != null) {
			return new ResponseEntity<CarResponse>(new CarResponse("Data Updated", car, null),
					HttpStatus.ACCEPTED);
		}
		// Failure
		return new ResponseEntity<CarResponse>(new CarResponse("Data Not Updated", null, null),
				HttpStatus.NOT_ACCEPTABLE);

	}
}
