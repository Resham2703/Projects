package com.jspiders.cardekho_REST.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jspiders.cardekho_REST.Pojo.CarAdminPojo;
import com.jspiders.cardekho_REST.Repository.CarAdminRepository;


@Service
public class CarAdminService {
	@Autowired
	private CarAdminRepository repository;

	public CarAdminPojo createAccount(CarAdminPojo pojo) {
		CarAdminPojo admin = repository.createAccount(pojo);
		return admin;
	}

	public CarAdminPojo login(CarAdminPojo pojo) {
		CarAdminPojo admin = repository.login(pojo);
		return admin;
	}

}