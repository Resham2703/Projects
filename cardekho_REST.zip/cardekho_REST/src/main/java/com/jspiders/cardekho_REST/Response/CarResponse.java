package com.jspiders.cardekho_REST.Response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.jspiders.cardekho_REST.Pojo.CarPojo;

public class CarResponse {

	@JsonInclude(JsonInclude.Include.NON_NULL)
	
	private String msg;
	private CarPojo car;
	private List<CarPojo>cars;
	
	
	public CarResponse(String msg, CarPojo car, List<CarPojo> cars) {
		this.msg = msg;
		this.car = car;
		this.cars = cars;
	}
	
	
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public CarPojo getCar() {
		return car;
	}
	public void setCar(CarPojo car) {
		this.car = car;
	}
	public List<CarPojo> getCars() {
		return cars;
	}
	public void setCars(List<CarPojo> cars) {
		this.cars = cars;
	}
	
	
	
	
	

}
