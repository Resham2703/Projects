package com.jspiders.cardekho_REST.Response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.jspiders.cardekho_REST.Pojo.CarAdminPojo;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CarAdminResponse {


	private String msg;
	private CarAdminPojo admin;


	public CarAdminResponse(String msg, CarAdminPojo admin) {
		// TODO Auto-generated constructor stub
		this.msg = msg;
		this.admin = admin;
	}


	public String getMsg() {
		return msg;
	}


	public void setMsg(String msg) {
		this.msg = msg;
	}


}
