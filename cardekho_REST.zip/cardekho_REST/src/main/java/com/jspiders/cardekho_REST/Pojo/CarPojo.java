package com.jspiders.cardekho_REST.Pojo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class CarPojo {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private int id;
	private String  car_Name;
	private String car_Brand;
	private String car_Fuel;
	private String car_Price;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCar_Name() {
		return car_Name;
	}
	public void setCar_Name(String car_Name) {
		this.car_Name = car_Name;
	}
	public String getCar_Brand() {
		return car_Brand;
	}
	public void setCar_Brand(String car_Brand) {
		this.car_Brand = car_Brand;
	}
	public String getCar_Fuel() {
		return car_Fuel;
	}
	public void setCar_Fuel(String car_Fuel) {
		this.car_Fuel = car_Fuel;
	}
	public String getCar_Price() {
		return car_Price;
	}
	public void setCar_Price(String car_Price) {
		this.car_Price = car_Price;
	}
	
	
}
