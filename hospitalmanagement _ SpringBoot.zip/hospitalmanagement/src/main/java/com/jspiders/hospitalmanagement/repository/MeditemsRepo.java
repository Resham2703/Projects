package com.jspiders.hospitalmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jspiders.hospitalmanagement.dto.Meditems;

public interface MeditemsRepo extends JpaRepository<Meditems, Integer>{

}
