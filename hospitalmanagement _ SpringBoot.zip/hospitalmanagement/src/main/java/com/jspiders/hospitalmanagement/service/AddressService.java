package com.jspiders.hospitalmanagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jspiders.hospitalmanagement.dao.AddressDao;
import com.jspiders.hospitalmanagement.dto.Address;

@Service
public class AddressService {

	@Autowired
	private AddressDao addressDao;

	public Address saveAddress(Address address) {
		return addressDao.saveAddress(address);
	}

	public Address updateAddress(Address address, int aid) {
		Address address2 = addressDao.updateAddress(aid, address);
		if (address2 != null) {
			return address2;
		} else {
			return null;
		}
	}

	public Address deleteAddress(int aid) {
		Address address = addressDao.deleteAddress(aid);
		if (address != null) {
			return address;
		} else {
			return null;
		}
	}

	public Address getAddressById(int aid) {
		Address address = addressDao.getAddressById(aid);
		if (address != null) {
			return address;
		} else {
			return null;
		}
	}
}
