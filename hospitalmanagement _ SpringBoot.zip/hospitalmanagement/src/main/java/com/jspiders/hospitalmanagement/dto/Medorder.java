package com.jspiders.hospitalmanagement.dto;

import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import lombok.Data;
//prescription
@Data
@Entity
public class Medorder {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int mid;
	private Date date;
	private String doctor;
	
	@ManyToOne
	private Encounter encounter;
}
