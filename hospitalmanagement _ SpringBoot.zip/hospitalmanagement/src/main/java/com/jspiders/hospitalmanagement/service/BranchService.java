package com.jspiders.hospitalmanagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jspiders.hospitalmanagement.dao.BranchDao;
import com.jspiders.hospitalmanagement.dto.Branch;

@Service
public class BranchService {

	@Autowired
	private BranchDao branchDao;

	public Branch saveBranch(Branch branch, int hid, int aid) {
		return branchDao.saveBranch(branch, hid, aid);
	}

	public Branch updateBranch(int bid, Branch branch) {
		Branch branch2 = branchDao.updateBranch(bid, branch);
		if (branch2 != null) {
			return branch2;
		} else {
			return null;
		}
	}
	
	public Branch deleteBranch(int bid) {
		Branch branch = branchDao.deleteBranch(bid);
		if (branch != null) {
			return branch;	
		}else {
			return null;
		}
	}
	
	public Branch getBranchById(int bid) {
		Branch branch = branchDao.getBranchById(bid);
		if (branch != null) {
			return branch;	
		}else {
			return null;
		}
	}
}
