package com.jspiders.hospitalmanagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jspiders.hospitalmanagement.dao.MedorderDao;
import com.jspiders.hospitalmanagement.dto.Medorder;

@Service
public class MedorderService {

	@Autowired
	private MedorderDao medorderDao;

	public Medorder saveMedorder(Medorder medorder, int eid) {
		return medorderDao.saveMedorder(medorder, eid);
	}

	public Medorder updateMedorder(int mid, Medorder medorder) {

		Medorder medorder2 = medorderDao.getMedorderById(mid);
		medorder.setEncounter(medorder2.getEncounter());
		Medorder dbMedorder = medorderDao.updateMedorder(mid, medorder);
		if (dbMedorder != null) {
			return dbMedorder;
		} else {
			return null;
		}
	}

	public Medorder deleteMedorder(int mid) {
		Medorder medorder = medorderDao.deleteMedorderById(mid);
		if (medorder != null) {
			return medorder;
		} else {
			return null;
		}
	}

	public Medorder getMedorderById(int mid) {
		Medorder medorder = medorderDao.getMedorderById(mid);
		if (medorder != null) {
			return medorder;
		} else {
			return null;
		}
	}
}
