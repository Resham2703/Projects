package com.jspiders.hospitalmanagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jspiders.hospitalmanagement.dto.Hospital;
import com.jspiders.hospitalmanagement.service.HospitalService;

@RestController	
@RequestMapping("/hospital")
public class HospitalController {

	@Autowired
	private HospitalService hospitalService;
	
	@PostMapping
	public Hospital saveHospital(@RequestBody Hospital hospital) {
		return hospitalService.saveHospital(hospital);
	}
	
	@PutMapping
	public Hospital updateHospital(@RequestParam int hid,@RequestBody Hospital hospital) {
		return hospitalService.updateHospital(hid, hospital);
	}
	
	@DeleteMapping
	public Hospital deleteHospital(@RequestParam int hid) {
		return hospitalService.deleHospital(hid);
	}
	
	@GetMapping
	public Hospital getHospitalById(@RequestParam int hid) {
		return hospitalService.getHospitalById(hid);
	}
}
